let progress = 0;
const progressBar = document.getElementById('progressBar');
const increaseBtn = document.getElementById('increaseBtn');

increaseBtn.addEventListener('click', () => {
  if (progress < 100) {
    progress += 25; // Increase by 25% each step
    progressBar.style.width = progress + '%';
  } else {
    alert("🎉 Booking process complete!");
  }
});
